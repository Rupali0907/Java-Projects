import java.util.*;
import java.util.Timer;
import java.util.TimerTask;


public class Main {

    static Scanner scanner = new Scanner(System.in);

    static int time = 60;
    static boolean answered = false;

    public static void main(String[] args) {

        boolean playAgain = true;

        while (playAgain) {

            startQuiz();

            System.out.println("\nDo you want to play again?");
            System.out.println("1.Yes");
            System.out.println("2.No");

            int choice = scanner.nextInt();

            if (choice == 2) {
                playAgain = false;
            }
        }
        System.out.println("Thanks for playing the Quiz !!");
    }

    //Quiz Method
    public static void startQuiz() {

        String[] questions = {"What is the main function of a router ?",
                "Which part of the computer is considered the brain ?",
                "What year was facebook launched ?",
                "Who is the known as the father of computer ?",
                " What was the first programming language ?",
                "Which company developed java ?",
                "Which keyword is used to inherit a class in java",
                "Which data structure uses FIFO?",
                "Which loop runs at least once ?",
                "Which operator is used for comparison ?"};


        String[][] options = {{"1.Storing the files", "2.Encrypting Data", "3.Directing Internet traffic", "4.Managing passwords"},
                {"1.CPU", "2.Hard Drive", "3.RAM", "4.GPU"},
                {"1.2000", "2.2004", "3.2006", "4.2008"},
                {"1.Steve Jobs", "2.Bill Gates", "3.Alan Turning", "4. Charles Babbage"},
                {"1.COBOL", "2. FORTRAN", "3.C#", "4. Assembly"},
                {"1.Microsoft", "2.Google", "3.Sun Microsystems", "4.IBM"},
                {"1.implement", "2.extends", "3.inherit", "4.import"},
                {"1.Stack", "2.Queue", "3.Array", "4.Tree"},
                {"1.for loop", "2.while loop", "3.do while loop", "4.if statement"},
                {"1.=", "2.==", "3.!=", "4.<>"}};
        int[] answers = {3, 1, 2, 4, 2, 3, 2, 2, 3, 2};
        int score = 0;


        System.out.println("*****************************");
        System.out.println("Welcome to the java quiz game");
        System.out.println("*****************************");

        //Random questions order
        List<Integer> order = new ArrayList<>();

        for (int i = 0; i < questions.length; i++) {
            order.add(i);
        }
        Collections.shuffle(order);

        for (int index : order) {

            answered = false;
            time = 20;

            System.out.println("\n" + questions[index]);

            for (String option : options[index]) {
                System.out.println(option);
            }
            Scanner sc = new Scanner(System.in);
            Timer timer = new Timer();

            System.out.println("Time Started (30 sec)");
            timer.schedule(new TimerTask() {
                public void run() {

                    if (!answered) {
                        System.out.println("Time up !!");
                    }
                    timer.cancel();

                }
            }, 20000);

            System.out.print("Enter you guess: ");
            int guess = scanner.nextInt();

            answered = true;
            timer.cancel();

            if (guess == answers[index]) {
                System.out.println("*******");
                System.out.println("CORRECT");
                System.out.println("*******");
                score++;
            } else {
                System.out.println("*****");
                System.out.println("WRONG");
                System.out.println("*****");
                System.out.println("Correct Answer is: " + answers[index]);


            }
        }
        showResult(score, questions.length);2

    }

        //Result method
        public static void showResult ( int score, int total){
            int percentage = (score * 100) / total;

            System.out.println("\n********************");
            System.out.println("Quiz Finished");
            System.out.println("**********************");

            System.out.println("Your Score: " + score + " / " + total);
            System.out.println("Percentage: " + percentage + "%");

            switch (percentage / 10) {

                case 10:
                case 9:
                case 8:
                    System.out.println("Grade A Excellent");
                    break;

                case 7:
                case 6:
                    System.out.println("Grade: B Good");
                    break;

                case 5:
                case 4:
                    System.out.println("Grade: C Average");

                default:
                    System.out.println("Grade:D Need Improvement");
            }

        }
    }